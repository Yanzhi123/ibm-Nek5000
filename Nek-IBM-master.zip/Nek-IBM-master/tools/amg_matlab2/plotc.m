function plotc(d,u)
    plotint(intpc(d,u));
end
